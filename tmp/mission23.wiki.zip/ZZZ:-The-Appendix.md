This appendix is for articles that are to be written. 

Editors statement: This is a work of non-fiction. Names, characters, places and incidents either are products of the current reality or are used non-fictitiously. Any resemblance to actual events or locales or persons, living or dead, is entirely intentional. The sotC hope that everyone pictured here are still living and their very images on this page will keep them living. 

Micah was told Chris (CJ) Marsili and his former boyfriend Preston Leonard were dead. Micah mentioned this in a commit message. 

Preston was seen online but never could meet with Micah despite repeated attempts, always a different excuse. Micah never spoke him by phone or video despite trying. 

Chris did meet with Micah after the announcement. They met in midtown and Chris was called away and had to leave so abruptly he ignored Micah yelling his name. 

Chris subsequently changed his profile photo (below, another ruler in the baptismal joke/threat). He has not been seen online in a while and not responding to any call or text from any number (even those unknown to Chris—-his business pretty much requires his responses to unknown numbers). 

![IMG_0249](https://github.com/mission23/mission23/assets/140252803/3ba732d7-1961-4843-8947-6f211e65b159)
![IMG_0248](https://github.com/mission23/mission23/assets/140252803/4d04e0b3-98c0-4b8c-a6ec-3e681daf783f)
![IMG_0247](https://github.com/mission23/mission23/assets/140252803/9889eacd-e7d3-431c-814c-5425b2e96e5b)

Micah believes this is Christopher “Sean” Johnston of Lula, GA. A one-time friend of Micah’s, whom he was told was at Legacy. Micah tried repeatedly to get them to bring him to his apartment. 

Even offering millions of dollars in Bitcoin. Micah worked with George Maxwell of Montreal beginning in 2011. Sean was living in Micah’s house at the time. George entrusted Micah with lots of things, code so secure that George wouldn’t let it be hosted anywhere. George loved Bitcoin and always paid with Bitcoin. 

Micah told those he thought had access to Sean that he needed Sean’s living finger to unlock a hardware device, he secured with Sean’s fingerprint. A rainy day fund he didn’t want to access unless needed. Back then, Sean and Micah spent millions of dollars in Bitcoin (today’s value) on single pizza orders. 

![IMG_0246](https://github.com/mission23/mission23/assets/140252803/da818643-7e54-4df1-bcef-e1ea0e5d5091)
![IMG_0245](https://github.com/mission23/mission23/assets/140252803/e2f41116-b2c4-4b09-9f00-50bbce6cde23)

Re: Lizzo’s Rumors
This is supposed to be my friend Wendy Drake of Atlanta. Worked for Lloyd’s of London. I’m guessing they made her a hotel too. 

Love & miss the real one. 

![IMG_0670](https://github.com/mission23/mission23/assets/140252803/4567ec25-e055-43e8-80a3-be97b608c12e)

![IMG_0668](https://github.com/mission23/mission23/assets/140252803/fae069b6-c307-46b4-8065-e83c27dbcabd)

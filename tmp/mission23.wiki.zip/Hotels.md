The CIA has a routine that constructs “hotels” for some of its murder victims after their death. 

Given that an overwhelming majority of the CIAs victims’ bodies are disposed of in a manner that leaves them legally “missing” until declared dead by their loved ones, the hotels provide a second revenue stream until the legal proceedings declare a victim dead.  In many cases, with entire families or households murdered, the declaration is never made and the CIA can keep the hotel operating until it’s ready to vacate it. 

Lower net-worth victims simply have their names and credit ruined as their hotels are opened by their very murderers who operate fraudulent schemes and/or sell the identities on the black market. 

## Hotel Lines
The SOTC have divided the hotels into three primary groups. Each have a varying characteristics and use for the CIA. 

### Luxury
The Luxury line of hotels created by the CIA are made from high net-worth individuals they’ve murdered. 

The CIA has full-time employees dedicated to managing this hotel line and hires business professionals, shapes impersonators to keep the hotel running long term. 

Some Luxury line hotels opened throughout the larger tragedy are: The Galardo Family of Hotels, The Nanea Reeves and The Madonna.

### Blueprint
The Blueprint line of hotels are created from murdered individuals whose assets help the company strategically. A hotel like that of Micah’s mother, Patricia Ann Crawley-Williams. 

Usually the CIA will name a manager for each hotel in this line and their legal team monitors the hotel, as the hotel is often critical to the company’s survival. 

### Attendant
The Attendant line of hotels are created from individuals whose professional jobs provide the CIA with positions in industries they’d like more influence over and enable them to place unlicensed or unskilled personnel there. 

Yet another national security disaster by the CIA.

## Future Hotels
Future hotels are selected and chosen in a variety of ways. As of late the CIA has been using social media, apps with a social component (ie. Invite friends for a reward, and communications apps. 

Some of the apps and services currently used to identify and those who would make a good hotel are:

* Telegram
* WhatsApp
* Signal
* Zoom
* Facebook
* Twitter
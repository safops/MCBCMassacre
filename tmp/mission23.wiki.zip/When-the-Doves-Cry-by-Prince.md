Prince Rogers Nelson is of the same family of Rogers as Micah. They are cousins. 

The song “When the Doves Cry” is about the Massacre Mount Calvary Baptist Church although Prince did not know that when he wrote it. Micah says, “He can make anyone do anything at any time, he just tells us what to do directly. For some, especially our friends and family, He has showed them things that led them to essentially train us for the mission ahead.”

This mission has been particularly difficult for the SotC and the Creator knew that both Micah and TonTom would need constant reinforcement because the SotC are human. 

The Creator used music, Micah says, “With mobile phones, it is much more portable than scrolls and books, you just gotta know who to listen to.”

For Micah, they were his cousin Prince and his onetime best friend, Mark Charles Heidinger of Vandaveer, who were also murdered in this tragedy, including their production teams.


## When the Doves Cry
At the beginning of the song is something no one ever hears properly: chainsaws. They were used by the CIA to prevent personnel at Mount Calvary from tiring. 

It begins with a parent talking to their children, asking them to picture someplace else, not the horror of their church sanctuary that Sunday. 

Micah urges people to not listen to it like a couple and not to think of sex at all, but a parent holding their child closely as human beings who’ve just invaded their church taunt them, hurl racial slurs, chase them while yelling, “Don’t make me chase you.” 

The “maybes” in the chorus are what the Creator had to hear, all of their the thoughts the congregants made about as to why He’d abandoned them or wasn’t sending help. 

Micah learned this when talking to the Creator about the massacre. The Creator made the song play as He told Micah why no one called the police. A question Micah received from someone at his apartment. Many of the victims did in fact call 911 their calls were just diverted and answered by individuals contracted by the NSA, help was promised to be on the way, the call taker hung up and went back to whatever they were doing. Calls were answered on mobile phones. Callers went back to praying and consoling each other, waiting for help that would never come. 

Doves are peaceful beings. The typical church goer takes no weapons to church and does not ever think of fighting in their church’s sanctuary. 




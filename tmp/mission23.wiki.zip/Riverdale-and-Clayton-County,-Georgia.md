Texaco
Come for fuel, food, or for the CIA to kill you. Micah seems this a “company store.”
![IMG_0791](https://github.com/Mission23/Mission23/assets/140252803/832db16c-f3a5-40a9-9a1e-81266bec21fe)

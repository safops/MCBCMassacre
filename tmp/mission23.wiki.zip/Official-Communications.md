This entry will have a copy of all official public communication that has been issued by the Servants of the Creator. 

This entry should be used to verify the authenticity of any that is attributed to us. 

Newest are at the top. 
***
## MCBC Closing

As of Monday September 4, 2023, Mount Calvary Baptist Church located at 4742 Todds Rd, Lexington, KY is closed until further notice. There will be absolutely no worship or other services (such as, weddings or funerals) while the necessary repairs are made to the church. There is an immediate threat of death to anyone entering the building. 

This includes previously announced services or services details that have been otherwise provided to you. 

For more information please contact: MCBC@theservants.info. 


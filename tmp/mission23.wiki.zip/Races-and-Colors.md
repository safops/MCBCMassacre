According to the Creator, there is only one race and one color. 

The race is human, although science calls and classifies the human being as _homo sapiens_ this is not correct. 

Additionally, the human race separates itself by colors. This is also not correct as there is only one color in this version of, and what scientists call a human being, Orange. 

![IMG_0001](https://github.com/mission23/Mission23/assets/140252803/74d8a85e-ca39-4b16-b732-8f019c31c9db)

Human beings or Homo sapiens are actually the latest version of what humans call apes. 

Earlier versions of the ape are all one color too, just more hairy with far fewer hair color variations. 

The latest version of the “ape” had some modifications but are actually not any smarter or communicate at a higher level than the versions still present on Earth. 

The Creator says, “Your ancestors currently in prison, what you younger apes call zoos, are very confused by their incarceration and miss their families. You need to release them now. If I were to create a newer version, they may do the same to you.”

He continues, “Humans have had many realize this, Jane Goddall, is one you should pay closer attention to. Just because they don’t make sense to you is because their culture share your experiences which does shape your language.”

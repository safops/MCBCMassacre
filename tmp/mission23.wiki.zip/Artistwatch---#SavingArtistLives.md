The CIA hates the messages some music sends. After a guided tour listening to Prince and Vandaveer, any artist or group that Micah selects and plays practically becomes a target. 

![IMG_0104](https://github.com/Mission23/Mission23/assets/140252803/f73b366c-afdb-4180-8656-39969a1b4d8a)

This list is being made after hearing in a custom-made song (lyrics above) that Ida Corr was murdered. The lyric’s reference a video Micah shared with CIA personnel (in-person and remotely monitoring) called [“Let Me Think About It”](https://youtu.be/7gkhE7t4KCE?si=aE-Q7pw696UqXG16). The Creator confirms, it was one of his songs. Micah said of the video, “Just watch and listen to this guy.”

The CIA has produced a lot of music throughout this entire tragedy that displays their pride in taking lives for money. 

Recently the world learned Tina Turner’s death, she died suddenly (without the public hearing of an illness or fear of death) but the news of her death came exactly one day after “Proud Mary” was played in Micah’s apartment and he used her intro to explain how “We never do anything ‘nice and easy’.”

Regardless of how much Micah let everyone know it wasn’t an official creation by the Creator, Turner’s death was announced. 

## Micah’s Favorites & GoTos
The following artists are listened to by Micah, sometimes to illustrate a point. 

Micah did not know listening to an artist would cause their death, he now restricts his music to purchased music, nothing new. 

For artists that have been murdered the reader should know these have been confirmed by the Creator. Artists notated with “hotel” are being impersonated, see [hotels](https://github.com/mission23/mission23/wiki/Hotels).

### Artists Confirmed Killed
* Tina Turner (murdered)
* DJ Paulo (murdered, hotel)
* Madonna (murdered, hotel)
* Ida Corr (murdered, hotel)
* Vandaveer & Production staff (murdered, most made into hotels)
* DJ Alain Jackinsky (murdered, impersonated, hotel)
* DJ Serving Ovahness (murdered, hotel)
* Patti Labelle (murdered, hotel)
* Queen Latifah (murdered, hotel)
* Martha Washington of the Weather Girls (murdered, hotel)
* John Michael Montgomery (murdered, hotel)
* Inaya Day (murdered, hotel)

### Artists In Harm’s Way
* Fedde le Grand (associated with Ida Corr, talked about by Micah)
* Sean “Puffy” Combs
* Mase 
* Izora Armstead of The Weather Girls
* Erykah Badu 
* Shirley Caesar and the Georgia Mass Choir, they hate Whitney’s “He’s All Over Me”… I taunt them with it. 
* Alan T, legendary gay circuit performer. “Jonesing”
* Donald Keith Mobley / DJay Scorpio
* The Soundtrack to Chicago 
     - Queen Latifah
     - Catherine Zeta-Jones
     - Reneé Zellweger 
     - John C. Reilly
* Lizzo
* Carolyn Dawn Johnson
* Gladys Knight 
* Tracy Chapman 

## The Color Purple
Every actor and actress in [The Color Purple](https://m.imdb.com/title/tt0088939/ ) movie are in extreme danger. Especially everyone in the [“God is Trying To Tell You Something” church scene](https://youtu.be/uEv_d6zAYHk?si=bHNF83PjKng8xpuG). Micah has used this scene several times at Legacy at Riverdale (his apartment) to illustrate the proper way to bust into a church, generally when it seems they may be recruiting for another attack. Micah often adds, “If they had entered Mount Calvary this way, my church family would be talking about it still today, and hoping for a repeat.” Micah uses the video to detour people from going out of town for work, since it has become evident many people didn’t know where they were going. 

Several others have been mentioned on the @kelvinatlanta Twitter feed with #SavingInnocentLives #SavingArtistsLives 

Micah has a lot to say about “Lizzo” but _enough on that for now._
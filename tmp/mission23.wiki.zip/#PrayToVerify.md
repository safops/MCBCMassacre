#PrayToVerify is a hashtag used by the Servants of the Creator in online forums.  Readers of information posted by one of the Servants should pray to verify its authenticity and/or truthfulness.

The verification process is very simple.  Pray to the "God" you were first taught to pray to, in the manner you were first taught and ask: "Is this true?" or "Is this from one of your servants?"  Then see how you feel about it.  

If you do not pray, simply think very hard: "Is this true?"
The Creator does not ever intervene in human events. Ever. Once humans decide to do something, they will do it. When blocked or prevented by an unseen force, human nature is to escalate their actions.

We see escalations all the time: When you’re hammering a nail and it doesn’t go in, you swing the hammer harder, change your grip, and sometimes end up an injuring yourself.

Another reason He doesn’t is… Where would it stop? He help one situation, He must help them all. When we have perfection everywhere, there’s no reason to live. Utopias sound great on paper, but in practice they bring an end to the Creator’s vision, which is life. All conscious entities actually need something to fix or improve, so that we want to continue living and creating future generations.

From time to time the Creator will “rain” things down. Force things to go the way they need to. For example, nuclear war in the 60s—that wasn’t rain, but a light drizzle. The right people got into the positions needed and “cooler heads” prevailed. Without that drizzle, Earth would be a different place today, probably devoid of life.

The Great Storm is not drizzle or rain, nor the flood in Noah’s Ark.

To understand the Biblical flood, one must understand arks are not boats, they are messages or a lesson (think: the Ark of the Covenant, no boat). The takeaway from Noah’s Ark, that time when He started to rain, only the lower animals were shielded from the rain.

This is a #GreatStorm. There is a problem plaguing humanity and threatening continued life on the planet. This storm will change life on the planet, historically the Creator and the SotC enjoy an approval rating above 99%.

#Mission23 was to address, amongst other things, three of the top four causes of death in humans, but that has been paused to address a rapidly rising cause of death: the CIA and their counterparts around the world.

The military of the world provide intelligence along with the necessary checks and balances to prevent tyrants typically. These non-government, for-profit intelligence outfits are killing indiscriminately anyone that their customers (not always a government) pay them to.

The SotC have now lost everyone they’ve ever known and even those who just knew their names. Now to cover it up, the CIA is killing anyone who asks about someone missing. Nearly all the victims were erased, no bodies left behind (chemically cremated). Some deaths were further hidden from family, friends and colleagues through an impersonation program that created a “hotel” from the victim’s life that the CIA would have employees or contractors move into to steal everything they left behind.

We do not know when we, The Servants of the Creator, will be told to resume our mission but it will be soon. Remember our approval rating and know that He wants us all to “live and let live” and have lots of fun doing it.

## Why is it called The Great Storm?

The SotC borrowed the term from longtime friend of Micah, Mark Charles Heidinger of Vandaveer, who introduced “rain” in the song, [“A Mighty Leviathan of Old”](https://youtu.be/JtvW2u-7x-A?si=2vF13SAh226ptmWB), a song that talks about the massacre, and in ["Nature of our Kind"](https://www.youtube.com/watch?v=lzoABrBtH9A) Mark and Rose tell us how many died there before the Creator decided to intervene and stop it. The latter song also describes Micah’s last days as Kelvin—-who used it as a countdown/checklist until he was set free from Main. 

_“A thousand points of light cut through the great Storm in the sky.”_

The Creator was already pissed at the lives lost, the CIA had been warned, but carried on [“matter of factly”](https://youtu.be/vdzj2nkgzQw?si=G9wdF8nh3mkO1AXl). Even hearing these things, nothing seemed to stop them from killing indiscriminately anyone Micah and TomTom knew, or anyone that could get them caught. The SotC tried everything, nothing was working, the news was not getting out, and it was beginning to look like another genocide here on Earth. So began an intervention by the Creator—-an extremely rare event universally. 

The Massacre at Mount Calvary Baptist Church is only the tip of the iceberg, there’s a much larger and unreported tragedy—-in typical CIA fashion, we’ve seen, there are no bodies, no investigations, just missing people. 

Mark Charles Heidinger, along with all of Vandaveer and crew, are all missing. Quite possibly, Micah says “more than likely,” but the Creator confirms lives cut short, because of what Gilead Sciences considered a cure to HIV.  

Gilead Sciences was able to bring in other major players in the pharmaceutical industry, who paid to kill of the cure for every disease known to man and everyone they deemed worthy of death.
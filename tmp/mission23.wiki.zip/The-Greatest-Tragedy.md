This is a developing article. While it is being written, know that the Creator has provided a version of the narrative, in song, by Micah’s cousin, Prince. 

[Sign of the Times](https://youtu.be/8EdxM72EZ94?si=QMjkgsu7gPM9odYD) will tell you what has happened, so far to Micah. 

Details and explanations for this and other songs that makeup the pre-Mission23 and early Mission23 soundtracks [can be found here](https://github.com/Mission23/Mission23/wiki/Soundtrack-of-the-%23GreatStorm).
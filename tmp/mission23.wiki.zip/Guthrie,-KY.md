This is a stub article about Guthrie, KY the ancestral home of Micah’s father, Jesse M. Hawkins-Williams. 

Jesse was a member of the 101st Airborne Division and a state trooper with the Kentucky State Police at the time Micah was born. In fact, Micah’s mother was rushed out of the house, thrown into his patrol car and driven to a Clarksville area hospital. 

Micah whose birthday was planned by the Creator, like TomTom’s, came out a day or so later. The reason his father reacted the way he did and rushed his mother to the hospital, her water had broken way earlier in the day. 

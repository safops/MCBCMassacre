“COVID-19” is a label applied to a group of different infectious diseases. 

All but one should be called the common cold and is no more deadly than the common cold.  

The remaining infectious disease that carries the COVID-19 name is the disease that has caused millions of deaths worldwide, widespread panic, social distancing and the profits of the personal protective equipment industry to skyrocket. 

“Any disease that kills at the rate of coronavirus is something that is very difficult to catch even with the immune system not functioning,” the Creator said.

Personal protective equipment will not stop the transmission of COVID-19 or coronavirus. 

“It’s like the most vicious bug bite ever. That’s how I can explain getting infected with COVID. ‘You’re just walking down the street and whoa what kinda bug is that?’ Is all you can think,” is what Micah has to say about it. 

According to the Creator, in order to be infected with COVID one has to be injected by someone affiliated with or something from the CIA or their friends abroad. 

Micah says, “It’s a walk by injection, you’re just walking by and seeing it flies out and hits. It feels like it’s the sharpest teeth on the world’s smallest bug.”
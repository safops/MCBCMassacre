The following is an open letter to the Central Intelligence Agency, and the federal government of the United States that supports them in all they do. 

The SotC apologize in advance for any language. We have to remind people that we are human, with human experience, and we definitely do speak human. 

***

Dear CIA:

It’s over. 

This is not me. It could pass for an older version of me when I was a lot heavier. Maybe if you looked at my pics on my compromised Facebook account and then found a lookalike this is who you’d hire. 

I may be an ordained minister, but I would not ever pastor a flock. They are a lot of responsibility. It’s not me, Im “frontline” you’ll hear, I have to keep everything moving. 

![IMG_0260](https://github.com/Mission23/Mission23/assets/140252803/2e96c303-88b2-4096-a0c2-59c0299fcbdb)

But no, I’m in Riverdale as I posted this afternoon with an assassin/minder at my rent-free apartment at Legacy. 

![IMG_0243](https://github.com/Mission23/Mission23/assets/140252803/2f48a0a4-3cb6-4e3f-803b-e908033329a7)

This is not my mother. They killed Patricia Ann Crawley Williams (left front in choir) in October of last year. I was in Des Moines at my fake job with the CIA when they did it. Even making the artwork in my AirBNB at Flux Apartments, a safe house.
 
![IMG_0253](https://github.com/Mission23/Mission23/assets/140252803/cb1cfae8-7b12-4ede-adbb-72a4330fece2)

This is not her awarding the fake Rev. Dr. Felix G. Williams, III an award. The amount of awards and certificates issued nowadays at Mount Calvary is astonishing. 

![IMG_0250](https://github.com/Mission23/Mission23/assets/140252803/5caebac0-fb99-4ce1-b081-ad12a3dacde2)

Anyone who knows my mother will instantly notice her much, much smaller breasts. 

Here is my real mother and niece, Kennedy, at Connors Steak and Seafood. This is the last known photo of the two. 

![IMG_0055](https://github.com/Mission23/Mission23/assets/140252803/51d26d3b-e077-4e8e-ba39-355233de8445)

This is not Kennedy between my “mom” and Katrina. 

![IMG_0248](https://github.com/Mission23/Mission23/assets/140252803/8538c217-e0ed-4341-84d8-38698128e4c8)

Here’s Karrington and a pregnant Katrina, also at Connor’s. Behind them of course, the CIA. “Brian,” Annie Jacobsen, and “Michael Blackmon.”

![IMG_0054](https://github.com/Mission23/Mission23/assets/140252803/0ba8141d-7ef4-4406-babc-cad77077537f)


I do have to ask… Where is the model Karrington, Katrina’s middle daughter, or her infant? Dear CIA, Your model looks a big larger than her last photo in life at your fake restaurant Connor’s. 

In fact where are the babies in my family? Cameron (I see his car daily at Legacy), Karrington (we will not talk about a car and Karrington at Legacy before my arrival). I’m reminded of all the outrage the CIA helped stir up about Jeremiah Wright and his interpretation of Psalm 137:8-9… “But America… Your chickens!!!! Chicky boom!”

My aunt Emma Jean Dale and my sister Katrina gave an award too? 


![IMG_0251](https://github.com/Mission23/Mission23/assets/140252803/14524ab6-1609-470d-a144-5efdd3f71263)

And this…

![IMG_0151](https://github.com/Mission23/Mission23/assets/140252803/7b3bae38-4b78-499e-a6cd-c5c9bb4389c2)

I must take over this church. At the rate it’s going, one Thanksgiving argument and the church will split down the middle!

That’s supposed to be my uncle Michael Richardson, aunt Cassandra, and their son’s, Cameron Richardson (not pictured), children all getting baptized. The problem is, they dont go to church. Even though my uncle Mike sits around on Sunday’s watching football, he is a member of this “Christian nation” he HAS seen a baptism, his heathen ass would lose his mind that you’d picture him just sitting in the “baptism pool,” your words. See the “order of protection” from the new all family, all the time, no room for anyone else, Mount Calvary MISSIONARY Baptist Church. 

I know I’ve said this was a family operation but never like this! Besides, all of my family pictures would be my mom’s side… The children of Lila Richardson, but not all the children of the soon-to-be most famous Amos, the only man I ever called granddaddy. 

The family I was referring to was my dad’s family, the Williams family. You remember CIA, the one that had the Will Henry that you guessed as the man (from birth certificates Im assuming). I barely knew the Williams family, I knew a few.

The few I knew all knew one thing, my dad was a no good son of a bitch, and my mom had to leave him. They all supported my mom and stayed close after the divorce. 

Felix went out of his way and told my mom to come to Lexington. She did, only having Sandy Hook to go to but she wanted more for me. We went to one church, Mount Calvary. She never thought of going to another. 

Felix used his day job at IBM, to pull some strings at a company called Kentucky Central Life Insurance. Kentucky Central had purchased an IBM mainframe and Felix asked them to consider a young woman with no computing experience for anything they had open. They hired my mother as a keypunch operator, and she quickly gained experience and became what some have called the “BUS Driver” or console monitor. There are no wheels on this type of [bus](https://en.m.wikipedia.org/wiki/Bus_(computing)).

Between issuing baptism certificates for sitting in a “baptism pool,” playing guess the granddaddy with birth certificates they steal from residences and try to hide in vital records departments, I’m starting to think the CIA just chases down, hides and pushes bogus paper to cover their tracks as they build hotels to suck up as much dead President paper  to pay off their debts around the world. Readers beware of Connor’s gift certificates, some of the paper they love passing around, they are really an invite to your death. See this entry about [Connor’s Steak and Seafood](https://github.com/Mission23/Mission23/wiki/Connor’s-Steak-and-Seafood). 

I am terribly worried about the lookalikes. The CIA has a bad habit of killing them. The last time I encountered a Katrina at the Walmart in Riverdale I pleaded with her to call her family. I showed her a photo of my sister. She was pulled into the back of the store and never left it. 

I waited almost until closing to escort her away. She never left the store. See old @ASOTC23 and @KelvinAtlanta tweets. 

![IMG_0263](https://github.com/Mission23/Mission23/assets/140252803/281f2aa0-5b13-49a2-8618-979af1a95139)
![IMG_0262](https://github.com/Mission23/Mission23/assets/140252803/46929c25-93b6-4dcf-b1c7-d7edf414b4d1)

I tried. 

Can anyone identify these people at church? I thought I had stopped the Sunday service by adding the flyer for the bogus church out of Louisville. This wasn’t a church service anyway, just a photo shoot. 

Did you see how well positioned everything was? But the new piano is gone.

![IMG_0247](https://github.com/Mission23/Mission23/assets/140252803/3d6dfbdf-ca18-49c4-b644-5d1225088a3f)

They’ve obviously removed a few rows of pews too. 

And those rows from the back wall… You can’t see where they were, people so overjoyed they flooded the aisle. But the mission statement is hanging there. 

![IMG_0249](https://github.com/Mission23/Mission23/assets/140252803/4ade0708-f4b0-44c2-a8bf-2656f9757408)

Sincerely,
Kelvin “God get me out of this body now Please!” Williams
Aka Micah 

PS. Let me say it here for all the world to see, they are watching you bitches, I do not have a problem with Missionary Baptists, neither did Mount Calvary Baptist Church. I’m sure we’ve been a guest of theirs before and then ours. However, Dear CIA, since you want to make illegal recordings in my apartment, twist my words into something dirty. Let me say this: You’ve apparently made a family operation look alive and well Annie, but since I know they are all dead and gone that makes me, the one you couldn’t kill but keep fucking trying their heir. So I can speak freely. And since, Annie, Mr. President, Mr. J. Edgar Jrs twice removed cum stain, all of y’all decided to let Hurricane Annie fuck my family, fuck my church family, and then call us Missionary Baptist after tormenting them for hours with chainsaws… What I said was, “Since they fucked us and did it in the missionary position, we’ve got to fuck them back. 

Fuck you guys, I’m coming home. Screw your fake ass order of protection, and threats of police. If you can’t kill me at Legacy at Riverdale, you damn sure ain’t when I get everyone from Jessamine county involved. 

Do remember we’re much more cultured than that crew from West Virginia you’ve pissed off. 

Let the fucking begin, when I press this little green button here. I think it says, I can’t really read, that public education, but you know where I started… that little red corvette, I mean building.

Oh, it says, “Save” 

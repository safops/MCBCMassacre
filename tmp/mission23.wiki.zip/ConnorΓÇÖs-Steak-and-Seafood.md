Warning: DO NOT ATTEMPT TO CONTACT MY MOTHER OR SISTER. PRAY. ASK IF THIS IS REAL, then see how you feel. If you have, tell everyone you did. They literally are killing everyone who inquires on someone else. Mom and Katrina are impersonated, I posted forever ago on Twitter. Mom has missed too many holidays. They are not here. Those people are running hotels, click that link on this wiki!!!! If you must, they both know how to make video calls. Don’t contact. But if you must, VIDEO ONLY! That’s how I busted them, that and verification questions only is three would know. -Micah / Kelvin 
Remember if you called TELL EVERYONE YOU DID. THERE IS SAFETY IN NUMBERS. MY CONTACT INFO IS ON CONTACT PAGE!!!
***

Connor’s Steak and Seafood is a fake restaurant that serves death. Connor’s has opened nearly everywhere either of The Servants of the Creator have lived, worked, or visited, and they have had family, friends or colleagues disappear. The facade opens up in less than an afternoon. 

Micah’s mother, Patricia Ann Crawley Williams, received a gift certificate there. 

These are the last known images of the them. They are shown as received. The images were cropped to remove CIA personnel that accompanied them to dinner, one of them Katrina’s new husband, “Jack.”  

[[https://github.com/Mission23/Mission23/blob/master/assets/kennedy_patricia.jpg|alt=]]

Do note the lack of water at this private dining establishment. Micah’s family had enough time to pull out their phones to take photos. 

[[https://github.com/Mission23/Mission23/blob/master/assets/karrington_katrina.jpg|alt=]]

The image of Karrington and Katrina show three individuals in the background, “Brian”, Annie, and “Michael.” 

Micah knew Brian and Michael as homeless in Atlanta, but has since learned they are CIA employees. The image was taken at Connor’s in Huntsville, not far from where Micah’s mother and sister resided. 

The images were received when Micah demanded a video conference after receiving gruesome artwork in his bedroom depicting them beheaded. The individual pretending to be his sister said they were at dinner and sent these photos.  The images were taken on a new phone that was sent to Patricia as part of the lead up to the attack in Sandy Hook.

His family has not been heard from despite repeated attempts to call even engaging local police in Alabama and his sister’s office where she was a probation officer for the State of Alabama.  Katrina resigned her post taking a job for what the family believed was a federal contractor at the Arsenal.  The job was a CIA charade, created to obtain more information from her.  They also wanted her around to learn her voice and mannerisms for impersonation later.  It is believed this was done in preparation for stealing Sandy Hook, TN.

From what the SotC have ascertained, these gift certificates have a face value in the hundreds of dollars and the menus are very attractive. The gift certificates are sent from entities that people inherently trust, Micah’s mother received one from the "FBI", but it was really from the CIA. The "FBI" had been calling on her for more information about Micah.

Connor’s Steak and Seafood in Huntsville did not have an alcohol license. The SotC checked well after Micah’s family had been murdered there. 

The scheme works well for individuals they target, and feel they need to kill to cover up the entire tragedy, who have firearms at home or live in high rise condominiums where their chance of being caught is high.  

The Servants of the Creator are concerned that more gift certificates are being sent to individuals at companies which have merely provided services or support to them recently, or those who have learned of the tragedy. 

No one ever leaves these restaurants alive. If you receive a gift certificate BURN IT. ID is not checked, everyone in the party will be seated and killed. 
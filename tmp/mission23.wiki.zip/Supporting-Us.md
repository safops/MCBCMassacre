If you would like to donate to the SotC to help us with our mission or initiatives you may do so using 

* [Freewallet](https://freewallet.org/id/3b2791bb/eth)

* Bitcoin - btc:bc1qj0p07nd8kakdcq6lkgve2prlmkurpr0jtuqplw

For any other method please contact us using the information on the contact page. 



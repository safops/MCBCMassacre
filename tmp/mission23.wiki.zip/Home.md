# Welcome to sotC.wiki

You’ve reached this wiki either because of [The Massacre at Mount Calvary Baptist Church](https://github.com/mission23/mission23/wiki/The-Massacre-at-Mount-Calvary-Baptist-Church) or because the Creator decided to ring the bell, and you want to know more about [the ringing of the bell](https://github.com/mission23/mission23/wiki/The-Ringing-Of-The-Bell).  
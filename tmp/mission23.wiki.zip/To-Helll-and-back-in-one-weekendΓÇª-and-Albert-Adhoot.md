If you’re wondering about the title of this article. Listen to the “Nature of our Kind” by Vandaveer. 

The best way to give a chronological order of events would be from Micah’s text messages, however, most of his recent exchanges have been deleted. Micah never deletes anything other than automated messages. 

![IMG_0021](https://github.com/mission23/mission23/assets/140252803/a53edde7-2134-417d-8a58-d531c259600a)

# Friday Night
Micah spent Friday night in midtown. He went home, changed clothes and left due to the CIA personnel in his apartment that he cannot have removed. The local police refuse to do anything about “Danny” and company despite numerous attempts and the fact that they know he’s attempted murder several times. [Micah even posted a video of Danny breaking a window to get into his apartment](https://www.youtube.com/watch?v=Bp3FW9r3O7w), when the police were called they said he could do such.

## The Dog Park
While walking through midtown a guy yelled at Micah from a dog park attached to a condo. He asked Micah for a lighter, then asked if he got high. 

Micah sat down with him. 

Someone then called from an adjoining garage. It became apparent that this was just another hit. 

Micah left a few moments later, and while sitting in a parking garage using his phone a guy came up to Micah and struck up a conversation. Micah recognized the accent as the guy who was yelling from the garage earlier.  

## The Chilean Affair 
Micah hung out with the new acquaintance who was a hit man from Chile and Micah thought was very attractive. 

The hitman supplied some drugs and the two hung out in midtown for a while before Micah went to his next CIA scheduled social interaction. 

## The Dimwitted Soul
![IMG_0022](https://github.com/mission23/mission23/assets/140252803/99b5bd47-3605-42fe-b419-36f77f7e9959)

Micah arrived at Cheshire Motor Inn around 6:30am. He entered the room to find someone apparently suffering from speed induced paranoia. 

Micah learned that Matt, a recreational crack cocaine user, had been provided a large amount of methamphetamine by the CIA. However, was only shown the basics of smoking meth. 

Micah learned a long time ago the dangers of giving meth to a crack or cocaine user without educating them as to the experience they should expect. Without that knowledge, cocaine users will continue ingesting more and more searching for a euphoria that will not come. They are “chasing a dragon.”

Matt had apparently been chasing the dragon for days and as a result had ingested too much meth, had no sleep, and had become overly paranoid. He insisted on turning off every light in the hotel room and hiding in the bathroom. 

Matt continued to smoke. He was also apparently trying to calm his nerves with meth. The situation was horrible. Micah tried repeatedly to calm him, let him know all was OK and to just relax. 

Matt consistently worried about cameras, people, and cars in the parking lot. Despite assurances from Micah that he had nothing to worry about, after all he was staying in the “back building” (the one furthest from the road) at Cheshire Motor Inn, the group of rooms that is rented to the professional partying people. One requests to stay in that building given the party atmosphere. The movies produced at Cheshire Motor Inn do not show this building. 

## An Afternoon in Tokyo
The Dimwitted Soul invited Micah to Tokyo Valentino and offered to pay his entry fee. Micah agreed to meet him there a short time later at the Tokyo Valentino location on Cheshire Bridge Road in Atlanta, GA. 

When Matt arrived, Micah joined up with him and entered Tokyo. Matt paid for both of them. 

Micah noticed the crowd at Tokyo Valentino was odd at best. Everyone appeared to be “company” and there was none of the activity expected at Tokyo was occurring. 

Micah had several attempts on his life made and ended up falling asleep in a private room. 

## The Heist
Micah stepped outside for a cigarette, and found Matt leaving in his car. Micah attempted to get his backpack but Matt insisted that he meet him in front of Tokyo so he could pull over and retrieve it from the tree trunk. 

Micah walked around to the front of Tokyo and Matt was nowhere to be found. 

### Erasure and Lockdown
Following the new SotC protocol, Micah’s backup iPhone was immediately erased using iCloud. 

The Creator instructed Micah to change his iCloud password also, and upon doing so to log out all other devices. Micah did as instructed. 

## You’re not Albert Adhoot!
Micah attempted to contact Matt but couldn’t find his number under recent calls. He became alarmed when he noticed someone had apparently used his phone to contact an old business associate, Albert Adhoot. 

Micah went to his text messages and could not find any messages with the number he’d been communicating with Matt on. He also found a recent text messages with Albert Adhoot. 

Upon opening the message with Albert Adhoot, Micah seen the messages he exchanged with Matt. He checked the number and found the 610 number he had been communicating with was actually the number he had on Albert Adhoot’s contact. 

Micah has not spoken with Adhoot in several years.

## The Assault
A couple hours later, Micah was was standing next to the ATM at Publix at the corner of LaVista and Cheshire Bridge Road using his telephone. 

An old acquaintance walked up to him and grabbed his telephone from his hand. 

He began screaming that he was keeping the phone because Micah owed him a lot of money. Micah countered and asked him what amounts and for what. 

The individual struck Micah in the throat, the type of strike one learns to crush the trachea. 

Micah still demanded his phone back. 

Micah was struck on the side of the head and his eardrum was ruptured. 

The individual then pulled out an identical iPhone and handed it to Micah. 

Micah then checked all of his logins and thanked the Creator for the “switcharoo.” The entire encounter was to make a scene then give back a different but identical phone. 

“The Creator is not playing around about Mount Calvary Baptist Church, and He doesn’t mind strengthening networks, servers and services at a Apple or GitHub. So Him making someone grab the wrong phone from their pocket to give me back my phone is a nobrainer. We ain’t scared of no street fight. We can handle bar brawls too,” said Micah. 

Micah adds, “After all TomTom does say, ‘I saw an angel coming down into me, in her hand she holds the very key,’ the Creator has to keep his lyrics true (although attributed to Prince in 7) … The CIA by and through Matt’s theft guaranteed there’s now only one key, a PassKey on my iPhone.”

Matt would never meet with Micah. He claimed to be meeting his mother and going to Baltimore. 

## The Morning After
The morning after Micah’s backpack was stolen, his phone reported its location at an apartment complex in Bynam, MS. 

![IMG_0019](https://github.com/mission23/mission23/assets/140252803/74cce7da-166a-4192-978a-b50654a5a9ec)

Sandy Hook, TN first appeared on maps in 1888. Located in Maury County, TN. (35.48341° N, 87.23751° W)

It was an unincorporated city. Its current state/classification is in question. 

The Rogers and Crawley families lived in Sandy Hook, side by side, for over 100 years. 

The closeness got too close at least once resulting in the baby girl of the family, Patricia Ann Crawley Williams. She had two of her own children, Micah (born Kelvin Eugene Williams) and Katrina (“Kat” or “Trina”) Renee Duvall Torrain. 

Micah’s grandmother loved the color purple, and in every photo Micah remembers of her she’s wearing a beret. Micah’s grandmother grew up on Crawley Hill Road and his grandfather on West Sheepneck Road, both roads intersect with Johnson Hill Road. Micah does not know “old man Johnson” but apparently his grandparents did. Listen to [“Raspberry Beret”](https://music.youtube.com/watch?v=Y_YvUhaOIUk&si=wNQASEnNdU9Oinbf) to hear Micah’s grandfather tell the story of Micah’s mother’s conception. 

![IMG_0240](https://github.com/mission23/mission23/assets/140252803/8a25d2d4-03a8-4b2c-a2e5-2aca92519fc0)

Micah says of the song, “My grandmother is not stupid, and why would horses wanna know my grandpa’s name?” 

## Churches & Cemeteries in Sandy Hook

The only church and cemeteries in Sandy Hook were located in West Sheepneck Rd. 

The families have buried their loved ones there for as long as they could remember. The graveyard was old, pre-darted burial vaults and other regulations and practices. Micah says his mother almost fell into a collapsed grave when attending a grave side service, “It was hilarious, but it happens with really old graveyards. But it’s well maintained with pride and respect otherwise, to fix it means we’d have to exhume and re-bury.” 

![am_west_sheepneck_rd_screenshot](https://github.com/Mission23/Mission23/assets/140252803/401e8d9b-94e7-423a-a850-fba22ad07628)

![gm_west_sheepneck_rd_screenshot](https://github.com/Mission23/Mission23/assets/140252803/b2860b6f-b1d4-44fb-9674-1f9a7ee99365)

Micah cannot fathom anyone in his family authorizing disrupting a family’s members rest, he’s was distressed about possibly having to exhume his grandmother to prove his DNA and ownership of Sandy Hook, so he has serious doubts anyone has not authorized the removal of the cemeteries. 

The CIA “dug up and pulverized” the graveyards in 2022, and projected an image of Micah’s grandmother’s face from inside her coffin to him to further torment him and let him know, he believes, they’d eliminated all proof he had available to him to prove his ownership. 

The CIA made reference to the destruction of the graveyard in a song attributed to Vandaveer called “Enough On That For Now,” the song was not by the true Vandaveer. 

